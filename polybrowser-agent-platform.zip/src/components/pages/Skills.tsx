import React, { useState } from 'react';
import { Boxes, UploadCloud, Code, FileJson, FileText, X } from 'lucide-react';
import Markdown from 'react-markdown';
import { mockSkills, Skill } from '../../store';
import { useTranslation } from 'react-i18next';

export function Skills() {
  const { t } = useTranslation();
  const [selectedSkillDoc, setSelectedSkillDoc] = useState<Skill | null>(null);

  const mockMarkdownDoc = `
# Skill Documentation

This is the integrated documentation viewer for the selected skill. 

## Overview
This skill provides automated interaction capabilities for its target platform.

## Usage Example
\`\`\`json
{
  "action": "SearchKeywords",
  "payload": {
    "query": "tech news"
  }
}
\`\`\`

## Available Actions
- \`SearchKeywords\`: Performs a search query on the platform.
- \`ParseFeed\`: Extracts content from the resulting feed.

> Note: Ensure you have rented a tab group with the correct environment profile before executing this skill.
  `;
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-baseline gap-3">
          <h2 className="text-lg font-bold text-slate-100">{t('skills.title')}</h2>
          <span className="text-xs text-slate-500 uppercase tracking-widest font-bold">{t('skills.subtitle')}</span>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-1.5 rounded-md bg-cyan-600 text-white text-xs font-bold hover:bg-cyan-500 shadow-[0_0_20px_rgba(8,145,178,0.3)] flex items-center gap-1.5">
            <UploadCloud size={14} /> {t('skills.uploadJson')}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockSkills.map(skill => (
          <div key={skill.id} className="bg-slate-900/40 border border-slate-800 hover:border-cyan-500/50 rounded-xl overflow-hidden relative flex flex-col group transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            
            <div className="p-5 flex-1 relative z-10">
              <div className="flex justify-between items-start mb-4">
                <div className="p-2.5 bg-slate-800/50 text-cyan-400 rounded-lg border border-slate-700/50 shadow-[0_0_15px_rgba(6,182,212,0.1)] group-hover:shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-shadow">
                  <Boxes size={20} />
                </div>
                <span className="text-[10px] font-mono bg-[#05070a] text-slate-400 px-2 py-0.5 rounded border border-slate-800">
                  v{skill.version}
                </span>
              </div>
              
              <h3 className="text-sm font-bold text-slate-200 mb-1 uppercase tracking-wider">{skill.name}</h3>
              <p className="text-[10px] text-slate-500 mb-4 uppercase tracking-widest">Target: <span className="font-bold text-cyan-400">{skill.platform}</span></p>
              
              {skill.description && (
                <p className="text-xs text-slate-400 mb-4 line-clamp-2 leading-relaxed">{skill.description}</p>
              )}
              
              <div className="space-y-2 mt-4">
                <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">Perception & Action Blocks</p>
                <div className="flex flex-wrap gap-1.5">
                  {skill.actions.map(action => (
                    <span key={action} className="inline-flex items-center px-1.5 py-0.5 bg-[#05070a] text-slate-400 text-[10px] rounded border border-slate-800 font-mono">
                      {action}()
                    </span>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="bg-[#05070a]/50 border-t border-slate-800/50 px-5 py-3 flex justify-between items-center relative z-10">
              <div className="flex items-center space-x-3">
                <span className="text-[10px] text-slate-500 font-mono flex items-center">
                  <FileJson size={12} className="mr-1" /> skill_{skill.id}.json
                </span>
                {skill.docUrl && (
                  <button 
                    onClick={() => setSelectedSkillDoc(skill)}
                    className="text-amber-500 hover:text-amber-300 text-[10px] font-bold uppercase tracking-wider flex items-center transition-colors"
                  >
                    <FileText size={12} className="mr-1" /> Docs
                  </button>
                )}
              </div>
              <button className="text-cyan-500 hover:text-cyan-300 text-[10px] font-bold uppercase tracking-wider flex items-center transition-colors">
                <Code size={12} className="mr-1" /> View Source
              </button>
            </div>
          </div>
        ))}
        
        <div className="bg-slate-900/20 rounded-xl border-2 border-dashed border-slate-800 flex flex-col items-center justify-center p-6 text-slate-600 hover:text-cyan-400 hover:border-cyan-500/50 hover:bg-cyan-900/10 transition-colors cursor-pointer min-h-[260px] group">
          <UploadCloud size={40} className="mb-4 text-slate-700 group-hover:text-cyan-400 transition-colors" />
          <h3 className="text-sm font-bold mb-1 uppercase tracking-wider">Create New Skill</h3>
          <p className="text-[10px] text-center px-4 max-w-xs leading-relaxed text-slate-500 font-mono">Use the visual builder or upload a standard JSON to define a new platform's DOM structure.</p>
        </div>
      </div>
      
      {selectedSkillDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-[#05070a] border border-slate-800 rounded-xl p-6 w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl">
            <div className="flex justify-between items-center mb-6 shrink-0 border-b border-slate-800/50 pb-4">
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-3">
                <FileText size={16} className="text-amber-500" />
                Documentation: {selectedSkillDoc.name}
              </h3>
              <button onClick={() => setSelectedSkillDoc(null)} className="text-slate-500 hover:text-slate-300 transition-colors p-1 bg-slate-900 rounded border border-slate-800">
                <X size={14} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar markdown-body text-slate-300 font-sans text-sm prose prose-invert prose-p:text-slate-400 prose-headings:text-slate-200 prose-a:text-cyan-400 prose-code:text-amber-400 prose-pre:bg-slate-900/50 prose-pre:border prose-pre:border-slate-800">
              <Markdown>{mockMarkdownDoc.replace('Skill Documentation', `${selectedSkillDoc.name} Documentation`)}</Markdown>
            </div>
            <div className="pt-5 flex justify-end shrink-0 border-t border-slate-800/50 mt-4">
               <button onClick={() => setSelectedSkillDoc(null)} className="px-5 py-2 rounded bg-slate-800/80 text-slate-200 text-xs font-bold hover:bg-slate-700 transition uppercase tracking-wider border border-slate-700/50 hover:border-slate-600">Close Viewer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
