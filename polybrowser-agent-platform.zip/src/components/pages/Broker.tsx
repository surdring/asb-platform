import React, { useState, useEffect } from 'react';
import { Network, Link2, Copy, Trash2, CheckCircle2, Send, Activity, Zap } from 'lucide-react';
import { mockTabGroups, mockEnvironments, mockTasks } from '../../store';
import { useTranslation } from 'react-i18next';

export function Broker() {
  const { t } = useTranslation();
  const [messages, setMessages] = useState<string[]>([
    '→ [Broker] Auth Agent Client: success (Task: task-1)',
    '→ [Broker] Allocating Tab Group: tg-1 in Env: env-1',
    '← [Agent-task-1] action: "navigate", url: "https://xiaohongshu.com"',
    '→ [Browser-tg-1] Executing CDP Command: Page.navigate',
    '→ [Browser-tg-1] Event: DOMContentLoaded',
    '← [Agent-task-1] action: "extract", selector: ".feed-item"',
    '→ [Broker] Parsing HTML via Perception Layer...'
  ]);
  const [simulatedMessage, setSimulatedMessage] = useState('');
  const [msgRate, setMsgRate] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setMsgRate(Math.floor(Math.random() * 15) + 5);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleSimulateMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!simulatedMessage.trim()) return;
    setMessages(prev => [...prev, `← [Agent-Sim] ${simulatedMessage}`]);
    setSimulatedMessage('');
  };
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-baseline gap-3">
          <h2 className="text-lg font-bold text-slate-100">{t('broker.title')}</h2>
          <span className="text-xs text-slate-500 uppercase tracking-widest font-bold">{t('broker.subtitle')}</span>
        </div>
        <div className="flex gap-2">
          <div className="px-3 py-1 bg-slate-900 border border-slate-800 rounded text-[10px] text-slate-400 font-mono">WS_CONN: wss://broker.poly.local</div>
        </div>
      </div>

      <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-6 relative overflow-hidden mb-6">
        <h3 className="text-sm font-bold text-slate-100 mb-4 uppercase tracking-wider flex items-center">
          <Network className="mr-2 text-cyan-400" size={16} />
          Active Tab Groups (Rentals)
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[10px] uppercase font-bold tracking-wider text-slate-500">
                <th className="pb-3 px-2">Tab Group Name</th>
                <th className="pb-3 px-2">Environment</th>
                <th className="pb-3 px-2">Status</th>
                <th className="pb-3 px-2">Assigned Agent / Task</th>
                <th className="pb-3 px-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="text-xs">
              {mockTabGroups.map(tg => {
                const env = mockEnvironments.find(e => e.id === tg.environmentId);
                const task = mockTasks.find(t => t.id === tg.rentedByTask);
                
                return (
                  <tr key={tg.id} className="border-b border-slate-800/50 last:border-0 hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-2 font-medium text-slate-300 flex items-center">
                      {tg.name}
                      <span className="ml-2 text-[10px] text-slate-600 font-mono">({tg.id})</span>
                    </td>
                    <td className="py-3 px-2 text-slate-400">
                      <span className="inline-flex items-center px-2 py-0.5 rounded bg-slate-800/50 border border-slate-700/50 text-[10px] font-mono">
                        {env?.name || 'Unknown'}
                      </span>
                    </td>
                    <td className="py-3 px-2">
                      {tg.status === 'rented' ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded bg-amber-900/30 text-amber-500 border border-amber-500/30 text-[10px] font-bold uppercase tracking-wider">
                          <Link2 size={10} className="mr-1" /> Rented
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 rounded bg-emerald-900/30 text-emerald-500 border border-emerald-500/30 text-[10px] font-bold uppercase tracking-wider">
                          <CheckCircle2 size={10} className="mr-1" /> Available
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-2">
                      {task ? (
                        <div className="flex flex-col">
                          <span className="font-bold text-slate-300">{task.name}</span>
                          <span className="text-[10px] text-slate-500 font-mono">Task ID: {task.id}</span>
                        </div>
                      ) : (
                        <span className="text-slate-600 italic">None</span>
                      )}
                    </td>
                    <td className="py-3 px-2 text-right space-x-2">
                      <button className="text-slate-500 hover:text-cyan-400 transition-colors p-1" title="Copy WebSocket URI">
                        <Copy size={16} />
                      </button>
                      <button className="text-slate-500 hover:text-red-400 transition-colors p-1" title="Force Release">
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#05070a] rounded-xl p-4 text-[10px] font-mono overflow-hidden shadow-lg border border-slate-800 flex flex-col h-full">
          <div className="flex justify-between items-center border-b border-slate-800/50 pb-2 mb-3">
             <div className="flex items-center gap-2">
               <span className="text-slate-500 uppercase tracking-widest font-bold">Broker Command Bus (Live)</span>
               <span className="flex items-center gap-1 bg-emerald-900/20 text-emerald-500 px-1.5 py-0.5 rounded border border-emerald-500/20">
                 <Zap size={10} /> Connected
               </span>
             </div>
            <div className="flex items-center space-x-3">
              <span className="text-cyan-500 flex items-center gap-1">
                <Activity size={10} /> {msgRate} msg/s
              </span>
              <div className="flex space-x-1">
                <div className="w-2 h-2 rounded-full bg-red-900 border border-red-500"></div>
                <div className="w-2 h-2 rounded-full bg-amber-900 border border-amber-500"></div>
                <div className="w-2 h-2 rounded-full bg-emerald-900 border border-emerald-500"></div>
              </div>
            </div>
          </div>
          <div className="space-y-1.5 overflow-y-auto flex-1 h-48 custom-scrollbar pr-2 pb-2">
            {messages.map((msg, idx) => (
              <div key={idx} className={msg.startsWith('←') ? 'text-blue-400' : msg.includes('Event:') ? 'text-cyan-500' : msg.includes('Auth') ? 'text-emerald-500' : 'text-slate-400'}>
                {msg}
              </div>
            ))}
            <div className="text-emerald-500 animate-pulse mt-2">[{new Date().toLocaleTimeString()}] LISTENING: Awaiting instructions on Bus #0...</div>
          </div>
          
          <form onSubmit={handleSimulateMessage} className="mt-3 pt-3 border-t border-slate-800 flex gap-2">
            <input 
              type="text" 
              value={simulatedMessage}
              onChange={e => setSimulatedMessage(e.target.value)}
              placeholder="Inject raw JSON command..." 
              className="flex-1 bg-slate-900/50 border border-slate-700/50 rounded px-2 py-1.5 text-xs text-slate-300 outline-none focus:border-cyan-500/50 font-mono"
            />
            <button type="submit" className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded flex items-center gap-1.5 border border-slate-700/50 transition-colors">
              <Send size={10} /> <span className="uppercase font-bold tracking-widest text-[9px]">Send</span>
            </button>
          </form>
        </div>
        
        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-6 relative overflow-hidden flex flex-col justify-center">
          <h4 className="text-sm font-bold text-slate-100 mb-3 uppercase tracking-wider">How it works</h4>
          <p className="text-slate-400 text-xs mb-4 leading-relaxed">
            The Broker acts as the middleman between high-level Agent Skills and the low-level browser CDP (Chrome DevTools Protocol).
          </p>
          <ul className="space-y-3 text-xs text-slate-300">
            <li className="flex items-start">
              <div className="w-5 h-5 rounded bg-cyan-900/30 border border-cyan-500/30 text-cyan-400 flex items-center justify-center text-[10px] font-bold mr-3 mt-0.5 shrink-0">1</div>
              <span className="leading-relaxed">Agent requests a functional sandbox (Tab Group).</span>
            </li>
            <li className="flex items-start">
              <div className="w-5 h-5 rounded bg-cyan-900/30 border border-cyan-500/30 text-cyan-400 flex items-center justify-center text-[10px] font-bold mr-3 mt-0.5 shrink-0">2</div>
              <span className="leading-relaxed">Broker allocates tabs and provides a WebSocket URI to the Agent.</span>
            </li>
            <li className="flex items-start">
              <div className="w-5 h-5 rounded bg-cyan-900/30 border border-cyan-500/30 text-cyan-400 flex items-center justify-center text-[10px] font-bold mr-3 mt-0.5 shrink-0">3</div>
              <span className="leading-relaxed">Agent sends standardized JSON commands based on its Skill JSON.</span>
            </li>
            <li className="flex items-start">
              <div className="w-5 h-5 rounded bg-cyan-900/30 border border-cyan-500/30 text-cyan-400 flex items-center justify-center text-[10px] font-bold mr-3 mt-0.5 shrink-0">4</div>
              <span className="leading-relaxed">Broker translates commands into raw clicks, scrolls, and DOM parsing.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
