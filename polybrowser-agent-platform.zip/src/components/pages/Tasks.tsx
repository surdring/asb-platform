import React from 'react';
import { ListTodo, Play, Square, Settings, ChevronRight, X, Maximize2, RotateCcw, FastForward, TerminalSquare } from 'lucide-react';
import { mockTasks, mockSkills, mockEnvironments, mockTabGroups } from '../../store';
import { useTranslation } from 'react-i18next';

export function Tasks() {
  const { t } = useTranslation();
  const [tasks, setTasks] = React.useState(mockTasks);
  const [filterStatus, setFilterStatus] = React.useState<string>('all');
  const [sortBy, setSortBy] = React.useState<'date' | 'name' | 'status'>('date');
  const [isNewTaskModalOpen, setIsNewTaskModalOpen] = React.useState(false);
  const [selectedTask, setSelectedTask] = React.useState<any>(null);

  const [newTaskName, setNewTaskName] = React.useState('');
  const [newTaskSkill, setNewTaskSkill] = React.useState('');

  const handleCreateTask = () => {
    if (!newTaskName || !newTaskSkill) return;
    const newTask = {
      id: `task-${Date.now()}`,
      name: newTaskName,
      skillId: newTaskSkill,
      tabGroupId: mockTabGroups[0].id, // Mock assignment
      status: 'idle' as const,
      logs: ['[INFO] Task created', '[INFO] Awaiting broker allocation'],
      createdAt: new Date().toISOString()
    };
    mockTasks.unshift(newTask);
    setTasks([...mockTasks]);
    setIsNewTaskModalOpen(false);
    setNewTaskName('');
    setNewTaskSkill('');
  };

  const filteredTasks = tasks.filter(t => filterStatus === 'all' || t.status === filterStatus);
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (sortBy === 'date') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    if (sortBy === 'status') return a.status.localeCompare(b.status);
    return 0;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-baseline gap-3">
          <h2 className="text-lg font-bold text-slate-100">{t('tasks.title')}</h2>
          <span className="text-xs text-slate-500 uppercase tracking-widest font-bold">{t('tasks.subtitle')}</span>
        </div>
        <div className="flex gap-4 items-center">
          <div className="flex gap-2">
            <select 
              className="bg-[#05070a] text-slate-300 text-xs px-2 py-1.5 rounded border border-slate-700 outline-none focus:border-cyan-500"
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
            >
              <option value="all">{t('tasks.allStatuses')}</option>
              <option value="running">{t('tasks.running')}</option>
              <option value="completed">{t('tasks.completed')}</option>
              <option value="failed">{t('tasks.failed')}</option>
              <option value="idle">{t('tasks.idle')}</option>
            </select>
            <select 
              className="bg-[#05070a] text-slate-300 text-xs px-2 py-1.5 rounded border border-slate-700 outline-none focus:border-cyan-500"
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
            >
              <option value="date">{t('tasks.sortByDate')}</option>
              <option value="name">{t('tasks.sortByName')}</option>
              <option value="status">{t('tasks.sortByStatus')}</option>
            </select>
          </div>
          <button 
            onClick={() => setIsNewTaskModalOpen(true)}
            className="px-4 py-1.5 rounded-md bg-cyan-600 text-white text-xs font-bold hover:bg-cyan-500 shadow-[0_0_20px_rgba(8,145,178,0.3)] flex items-center gap-1.5"
          >
            <Play size={14} /> {t('tasks.newTask')}
          </button>
        </div>
      </div>

      <div className="bg-slate-900/40 rounded-xl border border-slate-800 overflow-hidden relative">
        <ul className="divide-y divide-slate-800">
          {sortedTasks.map(task => {
            const skill = mockSkills.find(s => s.id === task.skillId);
            const tg = mockTabGroups.find(t => t.id === task.tabGroupId);
            const env = tg ? mockEnvironments.find(e => e.id === tg.environmentId) : null;

            return (
              <li key={task.id} className="p-5 hover:bg-slate-800/30 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 w-full">
                    <div className={`mt-1 w-8 h-8 rounded shrink-0 flex items-center justify-center border ${
                      task.status === 'running' ? 'bg-amber-900/30 border-amber-500/30 text-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.2)]' :
                      task.status === 'completed' ? 'bg-emerald-900/30 border-emerald-500/30 text-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.2)]' :
                      'bg-red-900/30 border-red-500/30 text-red-500 shadow-[0_0_10px_rgba(239,68,68,0.2)]'
                    }`}>
                      {task.status === 'running' ? <Play size={14} className="ml-0.5" /> : 
                       task.status === 'completed' ? <ListTodo size={14} /> : 
                       <Square size={14} />}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center">
                          <button onClick={() => setSelectedTask(task)} className="hover:text-cyan-400 transition-colors flex items-center gap-2">
                            {task.name} <Maximize2 size={12} className="text-slate-500" />
                          </button>
                          <span className={`ml-3 text-[9px] px-2 py-0.5 rounded font-bold tracking-widest border ${
                            task.status === 'running' ? 'bg-amber-900/30 text-amber-500 border-amber-500/30' :
                            task.status === 'completed' ? 'bg-emerald-900/30 text-emerald-500 border-emerald-500/30' :
                            'bg-red-900/30 text-red-500 border-red-500/30'
                          }`}>
                            {task.status.toUpperCase()}
                          </span>
                        </h3>
                        <div className="flex flex-col items-end">
                        <p className="text-[10px] text-slate-500 font-mono">{new Date(task.createdAt).toLocaleString()}</p>
                        </div>
                      </div>
                      
                      <div className="mt-1.5 flex items-center space-x-2 text-[10px] text-slate-500 font-mono">
                        <span className="font-bold text-slate-400 flex items-center">
                          <Settings size={12} className="mr-1 text-cyan-700" /> {skill?.name}
                        </span>
                        <ChevronRight size={10} className="text-slate-700" />
                        <span>Env: <span className="text-slate-300">{env?.name}</span></span>
                        <ChevronRight size={10} className="text-slate-700" />
                        <span>Tab: <span className="text-slate-300">{tg?.name}</span></span>
                      </div>
                      
                      <div className="mt-3 bg-[#05070a] rounded p-3 font-mono text-[10px] text-slate-400 overflow-x-auto w-full border border-slate-800">
                        {task.logs.map((log, i) => {
                          const isWarn = log.includes('WARN') || log.includes('delegating');
                          const isInfo = log.includes('INFO');
                          return (
                            <div key={i} className={`whitespace-nowrap ${isWarn ? 'text-amber-400' : isInfo ? 'text-cyan-500' : ''}`}>
                              {log}
                            </div>
                          );
                        })}
                        {task.status === 'running' && (
                          <div className="flex items-center mt-1.5 text-amber-500 animate-pulse">
                            <span className="w-1.5 h-3 bg-amber-500 mr-2"></span> Awaiting execution sync...
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="ml-4 shrink-0 mt-1">
                    {task.status === 'running' ? (
                      <button className="text-[10px] uppercase font-bold tracking-wider px-3 py-1.5 bg-red-900/20 text-red-400 hover:bg-red-900/40 border border-red-500/30 rounded transition-colors">
                        Halt
                      </button>
                    ) : (
                      <button className="text-[10px] uppercase font-bold tracking-wider px-3 py-1.5 bg-slate-800/50 text-slate-300 hover:text-cyan-400 hover:border-cyan-500/50 border border-slate-700 rounded transition-colors">
                        Re-run
                      </button>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      </div>

      {isNewTaskModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-[#05070a] border border-slate-800 rounded-xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">Create New Task</h3>
              <button onClick={() => setIsNewTaskModalOpen(false)} className="text-slate-500 hover:text-slate-300">
                <X size={16} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-2">Task Name</label>
                <input 
                  type="text" 
                  value={newTaskName} 
                  onChange={e => setNewTaskName(e.target.value)} 
                  className="w-full bg-slate-900 shadow-inner border border-slate-700 rounded p-2.5 text-xs text-slate-200 outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition-all font-mono"
                  placeholder="e.g. Scrape new leads"
                />
              </div>
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-2">Select Skill</label>
                <select 
                  value={newTaskSkill} 
                  onChange={e => setNewTaskSkill(e.target.value)}
                  className="w-full bg-slate-900 shadow-inner border border-slate-700 rounded p-2.5 text-xs text-slate-200 outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition-all font-mono"
                >
                  <option value="" disabled>Select a skill...</option>
                  {mockSkills.map(s => <option key={s.id} value={s.id}>{s.name} ({s.id})</option>)}
                </select>
              </div>
              <div className="pt-4 flex justify-end gap-3 border-t border-slate-800/50 mt-6">
                <button onClick={() => setIsNewTaskModalOpen(false)} className="px-4 py-2 hover:bg-slate-800/50 rounded text-xs font-bold text-slate-400 hover:text-slate-200 uppercase tracking-wider transition-colors">Cancel</button>
                <button 
                  onClick={handleCreateTask}
                  disabled={!newTaskName || !newTaskSkill}
                  className="px-5 py-2 rounded bg-cyan-600 text-white text-xs font-bold hover:bg-cyan-500 shadow-[0_0_15px_rgba(8,145,178,0.3)] uppercase tracking-wider disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  Confirm
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {selectedTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-[#05070a] border border-slate-800 rounded-xl p-6 w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl">
            <div className="flex justify-between items-center mb-6 shrink-0 border-b border-slate-800/50 pb-4">
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-3">
                <ListTodo size={16} className="text-cyan-500" />
                Task Details: {selectedTask.name}
              </h3>
              <button onClick={() => setSelectedTask(null)} className="text-slate-500 hover:text-slate-300 transition-colors p-1 bg-slate-900 rounded border border-slate-800">
                <X size={14} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto space-y-6 pr-2 custom-scrollbar">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Status</span>
                  <div className="mt-1.5 flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-2 ${
                        selectedTask.status === 'running' ? 'bg-amber-500 shadow-[0_0_8px_#f59e0b] animate-pulse' :
                        selectedTask.status === 'completed' ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' :
                        selectedTask.status === 'failed' ? 'bg-red-500 shadow-[0_0_8px_#ef4444]' :
                        'bg-slate-500'
                    }`}></div>
                    <p className="text-xs font-mono text-slate-300">{selectedTask.status.toUpperCase()}</p>
                  </div>
                </div>
                <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Created Timestamp</span>
                  <p className="text-xs font-mono text-slate-300 mt-1.5">{new Date(selectedTask.createdAt).toLocaleString()}</p>
                </div>
                <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-800 col-span-2 flex items-center justify-between">
                   <div>
                     <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mb-1">Execution Pipeline</span>
                     <div className="flex items-center space-x-3 text-xs font-mono text-slate-400">
                       <span className="text-cyan-400">{selectedTask.skillId}</span>
                       <ChevronRight size={12} />
                       <span className="text-amber-400">{selectedTask.tabGroupId || 'Unassigned'}</span>
                     </div>
                   </div>
                   <Settings size={24} className="text-slate-700" />
                </div>
              </div>
              
              <div>
                <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center justify-between">
                  Live Execution Logs
                  <div className="flex gap-2">
                     <button className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-400 hover:border-cyan-500 transition-colors">
                       <FastForward size={10} /> Step
                     </button>
                     <button className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-400 hover:border-cyan-500 transition-colors">
                       <TerminalSquare size={10} /> Inject CMD
                     </button>
                  </div>
                </h4>
                <div className="bg-slate-900/80 p-4 rounded-lg border border-slate-800/80 font-mono text-[10px] text-slate-400 h-56 overflow-y-auto shadow-inner leading-relaxed">
                    {selectedTask.logs.map((log: string, i: number) => {
                      const isWarn = log.includes('WARN') || log.includes('delegating');
                      const isInfo = log.includes('INFO');
                      return (
                        <div key={i} className={`whitespace-pre-wrap py-1 flex items-start gap-2 group border-b border-slate-800/30 last:border-0 ${isWarn ? 'text-amber-400' : isInfo ? 'text-cyan-400' : ''}`}>
                          <button className="opacity-0 group-hover:opacity-100 mt-0.5 text-slate-500 hover:text-cyan-400 transition-opacity" title="Re-run this command">
                            <RotateCcw size={10} />
                          </button>
                          <span className="text-slate-600 mr-2">{(i+1).toString().padStart(2, '0')}&gt;</span> {log}
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
            <div className="pt-5 flex justify-end shrink-0 border-t border-slate-800/50 mt-4">
               <button onClick={() => setSelectedTask(null)} className="px-5 py-2 rounded bg-slate-800/80 text-slate-200 text-xs font-bold hover:bg-slate-700 transition uppercase tracking-wider border border-slate-700/50 hover:border-slate-600">Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
