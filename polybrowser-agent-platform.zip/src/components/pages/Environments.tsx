import React, { useState, useEffect } from 'react';
import { Server, Monitor, Chrome, Plus, History, Terminal, Activity, Cpu, MemoryStick as Memory, ArrowDownUp, X } from 'lucide-react';
import { mockEnvironments } from '../../store';
import { useTranslation } from 'react-i18next';

export function Environments() {
  const { t } = useTranslation();
  const [envs, setEnvs] = useState(mockEnvironments);
  const [healthStats, setHealthStats] = useState<Record<string, { cpu: number, mem: number, net: number }>>({});
  const [isNewProfileModalOpen, setIsNewProfileModalOpen] = useState(false);
  const [selectedEnvId, setSelectedEnvId] = useState<string | null>(null);
  const [newProfileName, setNewProfileName] = useState('');

  useEffect(() => {
    const updateStats = () => {
      const stats: Record<string, { cpu: number, mem: number, net: number }> = {};
      envs.forEach(env => {
        if (env.status === 'online') {
          stats[env.id] = {
            cpu: Math.floor(Math.random() * 60) + 10,
            mem: Math.floor(Math.random() * 40) + 40,
            net: Math.floor(Math.random() * 500) + 100,
          };
        } else {
          stats[env.id] = { cpu: 0, mem: 0, net: 0 };
        }
      });
      setHealthStats(stats);
    };
    updateStats();
    const interval = setInterval(updateStats, 3000);
    return () => clearInterval(interval);
  }, [envs]);

  const handleCreateProfile = () => {
    if (!newProfileName || !selectedEnvId) return;
    setEnvs(envs.map(env => {
      if (env.id === selectedEnvId) {
        return { ...env, profiles: [...env.profiles, newProfileName] };
      }
      return env;
    }));
    setNewProfileName('');
    setIsNewProfileModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-baseline gap-3">
          <h2 className="text-lg font-bold text-slate-100">{t('environments.title')}</h2>
          <span className="text-xs text-slate-500 uppercase tracking-widest font-bold">{t('environments.subtitle')}</span>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-1.5 rounded-md bg-cyan-600 text-white text-xs font-bold hover:bg-cyan-500 shadow-[0_0_20px_rgba(8,145,178,0.3)] flex items-center gap-1.5">
            <Plus size={14} /> {t('environments.addEnv')}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {envs.map(env => (
          <div key={env.id} className="bg-slate-900/40 border border-slate-800 rounded-xl overflow-hidden relative">
            <div className="flex items-center justify-between p-5 border-b border-slate-800/50 bg-[#05070a]/50">
              <div className="flex items-center space-x-4">
                <div className={`p-3 rounded-lg border ${
                  env.type === 'docker' ? 'bg-cyan-950/20 text-cyan-400 border-cyan-500/30 ring-1 ring-cyan-500/10' : 'bg-slate-900/50 text-slate-400 border-slate-700'
                }`}>
                  {env.type === 'docker' ? <Server size={20} /> : <Monitor size={20} />}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-200 flex items-center uppercase tracking-wider">
                    {env.name}
                    <span className={`ml-3 text-[10px] px-2 py-0.5 rounded font-bold tracking-widest border ${
                      env.status === 'online' ? 'bg-emerald-900/30 text-emerald-500 border-emerald-500/30' : 
                      env.status === 'error' ? 'bg-red-900/30 text-red-500 border-red-500/30 animate-pulse' :
                      'bg-slate-900/50 text-slate-500 border-slate-700'
                    }`}>
                      {env.status}
                    </span>
                  </h3>
                  <p className="text-[10px] text-slate-500 mt-1 flex items-center font-mono">
                    <span className="uppercase text-slate-400">{env.type} Context</span>
                    <span className="mx-2">•</span>
                    ID: {env.id}
                  </p>
                </div>
              </div>
              
              <div className="flex space-x-2 text-[10px] font-bold uppercase tracking-wider">
                <button className="flex items-center space-x-1.5 text-slate-400 hover:text-cyan-400 transition-colors px-3 py-1.5 rounded bg-slate-800/50 border border-slate-700/50 hover:border-cyan-500/50">
                  <Terminal size={12} />
                  <span>Terminal</span>
                </button>
                <button className="flex items-center space-x-1.5 text-slate-400 hover:text-cyan-400 transition-colors px-3 py-1.5 rounded bg-slate-800/50 border border-slate-700/50 hover:border-cyan-500/50">
                  <History size={12} />
                  <span>Logs</span>
                </button>
              </div>
            </div>

            <div className="bg-[#05070a]/30 border-b border-slate-800/50 px-5 py-3 grid grid-cols-3 gap-4">
               <div className="flex items-center text-slate-400 space-x-2">
                 <Cpu size={14} className={env.status === 'online' ? 'text-amber-400' : 'text-slate-600'} />
                 <span className="text-[10px] uppercase font-bold tracking-wider">CPU: {healthStats[env.id]?.cpu || 0}%</span>
               </div>
               <div className="flex items-center text-slate-400 space-x-2">
                 <Memory size={14} className={env.status === 'online' ? 'text-blue-400' : 'text-slate-600'} />
                 <span className="text-[10px] uppercase font-bold tracking-wider">MEM: {healthStats[env.id]?.mem || 0}%</span>
               </div>
               <div className="flex items-center text-slate-400 space-x-2">
                 <ArrowDownUp size={14} className={env.status === 'online' ? 'text-emerald-400' : 'text-slate-600'} />
                 <span className="text-[10px] uppercase font-bold tracking-wider">I/O: {healthStats[env.id]?.net || 0} KB/s</span>
               </div>
            </div>
            
            <div className="p-5 flex items-start justify-between">
              <div>
                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center">
                  <Chrome size={12} className="mr-2 text-cyan-500" />
                  Shared Profiles (Cookies/Storage)
                </h4>
                <div className="flex flex-wrap gap-2">
                  {env.profiles.map(profile => (
                    <span key={profile} className="inline-flex items-center px-2.5 py-1 bg-slate-800 border border-slate-700 text-[10px] font-medium text-slate-300 rounded uppercase tracking-wide">
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 mr-2 shadow-[0_0_8px_#06b6d4]"></div>
                      {profile}
                    </span>
                  ))}
                  <button 
                    onClick={() => { setSelectedEnvId(env.id); setIsNewProfileModalOpen(true); }}
                    className="inline-flex items-center px-2.5 py-1 bg-transparent border border-dashed border-slate-600 text-[10px] font-bold text-slate-500 hover:text-cyan-400 hover:border-cyan-500/50 rounded transition-colors uppercase"
                  >
                    <Plus size={10} className="mr-1" /> New Profile
                  </button>
                </div>
                <p className="text-[10px] text-slate-500 mt-3 font-mono">
                  Profiles persist login state and local storage. Agents can rent tabs initialized with a specific profile.
                </p>
              </div>
              
              <div className="text-right">
                <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Last Ping</p>
                <p className="text-xs font-mono text-cyan-400 mt-1">{new Date(env.lastPing).toLocaleString()}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {isNewProfileModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-[#05070a] border border-slate-800 rounded-xl p-6 w-full max-w-sm">
             <div className="flex justify-between items-center mb-6">
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">New Shared Profile</h3>
              <button onClick={() => setIsNewProfileModalOpen(false)} className="text-slate-500 hover:text-slate-300">
                <X size={16} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-2">Profile Name</label>
                <input 
                  type="text" 
                  value={newProfileName} 
                  onChange={e => setNewProfileName(e.target.value)} 
                  className="w-full bg-slate-900 shadow-inner border border-slate-700 rounded p-2.5 text-xs text-slate-200 outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition-all font-mono"
                  placeholder="e.g. MarketingTeam_FB"
                />
              </div>
              <div className="pt-4 flex justify-end gap-3 border-t border-slate-800/50 mt-6">
                <button onClick={() => setIsNewProfileModalOpen(false)} className="px-4 py-2 hover:bg-slate-800/50 rounded text-xs font-bold text-slate-400 hover:text-slate-200 uppercase tracking-wider transition-colors">Cancel</button>
                <button 
                  onClick={handleCreateProfile}
                  disabled={!newProfileName}
                  className="px-5 py-2 rounded bg-cyan-600 text-white text-xs font-bold hover:bg-cyan-500 shadow-[0_0_15px_rgba(8,145,178,0.3)] uppercase tracking-wider disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  Create
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
