import React, { useState } from 'react';
import { Sidebar } from '../Sidebar';
import { Dashboard } from '../pages/Dashboard';
import { Environments } from '../pages/Environments';
import { Broker } from '../pages/Broker';
import { Skills } from '../pages/Skills';
import { Tasks } from '../pages/Tasks';
import { Activity, Globe } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export function Layout() {
  const [currentTab, setCurrentTab] = useState('dashboard');
  const { t, i18n } = useTranslation();

  const toggleLanguage = () => {
    i18n.changeLanguage(i18n.language === 'en' ? 'zh' : 'en');
  };

  const renderContent = () => {
    switch (currentTab) {
      case 'dashboard': return <Dashboard />;
      case 'environments': return <Environments />;
      case 'broker': return <Broker />;
      case 'skills': return <Skills />;
      case 'tasks': return <Tasks />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="w-full h-full flex flex-col bg-[#05070a] text-slate-300 font-sans overflow-hidden">
      {/* Header Section */}
      <header className="h-16 border-b border-slate-800 flex shrink-0 items-center justify-between px-6 bg-[#0a0f1a] backdrop-blur-xl">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.4)]">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-slate-100">
            POLYMORPH <span className="text-cyan-400 font-mono text-sm ml-2 px-2 py-0.5 bg-cyan-900/30 rounded border border-cyan-800/50">v2.4.0-BETA</span>
          </h1>
        </div>
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]"></div>
            <span className="text-xs font-semibold uppercase tracking-widest text-emerald-500">{t('header.brokerOnline')}</span>
          </div>
          <div className="h-8 w-px bg-slate-800"></div>
          <div className="flex gap-4">
            <button onClick={toggleLanguage} className="px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 transition flex gap-1.5 items-center text-slate-300 text-xs font-bold uppercase">
              <Globe size={14} /> {i18n.language === 'en' ? 'EN' : 'ZH'}
            </button>
            <button className="px-4 py-1.5 rounded-md bg-slate-800 border border-slate-700 text-xs font-medium hover:bg-slate-700 transition-colors">{t('header.clusterConfig')}</button>
            <button className="px-4 py-1.5 rounded-md bg-cyan-600 text-white text-xs font-bold hover:bg-cyan-500 shadow-[0_0_20px_rgba(8,145,178,0.3)]">{t('header.newAgentTask')}</button>
          </div>
        </div>
      </header>

      {/* Main Content Layout */}
      <main className="flex-1 flex overflow-hidden">
        <Sidebar currentTab={currentTab} onTabChange={setCurrentTab} />
        
        <section className="flex-1 flex flex-col bg-[#020617] relative overflow-y-auto">
          <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#1e293b 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
          <div className="p-6 relative z-10 h-full flex flex-col">
            <div className="max-w-7xl mx-auto w-full">
              {renderContent()}
            </div>
          </div>
        </section>
      </main>

      {/* Bottom Status Bar */}
      <footer className="h-8 shrink-0 bg-[#0a0f1a] border-t border-slate-800 flex items-center justify-between px-4 text-[10px] font-mono tracking-tight text-slate-500">
        <div className="flex gap-6">
          <div className="flex gap-2"><span className="text-slate-600">{t('header.uptime')}</span> 128:44:12</div>
          <div className="flex gap-2"><span className="text-slate-600">{t('header.instances')}</span> 14/100</div>
          <div className="flex gap-2"><span className="text-slate-600">{t('header.cpu')}</span> 12.4%</div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-400"></div>
            <span>{t('header.apiGateway')}</span>
          </div>
          <div className="h-3 w-px bg-slate-700"></div>
          <span>{t('header.region')}</span>
        </div>
      </footer>
    </div>
  );
}
