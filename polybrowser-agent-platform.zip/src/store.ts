export type EnvironmentType = 'docker' | 'native';

export interface Environment {
  id: string;
  name: string;
  type: EnvironmentType;
  status: 'online' | 'offline' | 'error';
  profiles: string[];
  lastPing: string;
}

export interface TabGroup {
  id: string;
  environmentId: string;
  name: string;
  status: 'available' | 'rented';
  rentedByTask?: string;
}

export interface Skill {
  id: string;
  name: string;
  platform: string;
  version: string;
  actions: string[];
  docUrl?: string;
  description?: string;
}

export interface Task {
  id: string;
  name: string;
  skillId: string;
  tabGroupId: string;
  status: 'running' | 'completed' | 'failed' | 'idle';
  logs: string[];
  createdAt: string;
}

export const mockEnvironments: Environment[] = [
  { id: 'env-1', name: 'Docker Cluster Alpha', type: 'docker', status: 'online', profiles: ['Default'], lastPing: new Date().toISOString() },
  { id: 'env-2', name: 'Local Dev Mac', type: 'native', status: 'online', profiles: ['Work', 'Personal'], lastPing: new Date().toISOString() },
  { id: 'env-3', name: 'Docker Cluster Beta', type: 'docker', status: 'offline', profiles: ['Isolated-1'], lastPing: new Date(Date.now() - 3600000).toISOString() },
  { id: 'env-4', name: 'Docker Cluster Gamma', type: 'docker', status: 'error', profiles: ['Default'], lastPing: new Date(Date.now() - 7200000).toISOString() },
];

export const mockTabGroups: TabGroup[] = [
  { id: 'tg-1', environmentId: 'env-1', name: 'Group Alpha-1', status: 'rented', rentedByTask: 'task-1' },
  { id: 'tg-2', environmentId: 'env-1', name: 'Group Alpha-2', status: 'available' },
  { id: 'tg-3', environmentId: 'env-2', name: 'Local Native Window', status: 'rented', rentedByTask: 'task-2' },
];

export const mockSkills: Skill[] = [
  { id: 'skill-xhs', name: 'XHS Scraper', platform: 'Xiaohongshu', version: '1.2.0', actions: ['SearchKeywords', 'ParseFeed', 'ExtractComments'], docUrl: 'https://docs.example.com/xhs', description: 'Scrapes feed and extracts comments from given keywords.' },
  { id: 'skill-in', name: 'LinkedIn Connect', platform: 'LinkedIn', version: '2.1.4', actions: ['Login', 'SearchPeople', 'SendRequest'], docUrl: 'https://docs.example.com/linkedin', description: 'Automates connection requests directly from search results.' },
  { id: 'skill-amz', name: 'AMZ Price Monitor', platform: 'Amazon', version: '1.0.1', actions: ['CheckPrice', 'ParseReviews'], docUrl: 'https://docs.example.com/amazon', description: 'Monitors product prices and summarizes reviews.' },
];

export let mockTasks: Task[] = [
  { id: 'task-1', name: 'Daily XHS Feed', skillId: 'skill-xhs', tabGroupId: 'tg-1', status: 'running', logs: ['[INFO] Navigating to target...', '[INFO] Rented Tab Group tg-1', '[WARN] Captcha encountered, delegating to action layer...'], createdAt: new Date(Date.now() - 600000).toISOString() },
  { id: 'task-2', name: 'Lead Gen', skillId: 'skill-in', tabGroupId: 'tg-3', status: 'completed', logs: ['[INFO] Login shared from Local Native Window profile.', '[INFO] Sent 50 requests.', '[INFO] Task completed.'], createdAt: new Date(Date.now() - 7200000).toISOString() },
];
